#!/usr/bin/env python3
"""FreeMacCleaner - a free, open storage cleaner for macOS.
Run:  python3 FreeMacCleaner.py
It starts a private server on your Mac (127.0.0.1 only) and opens the app in your browser.
Nothing is uploaded anywhere. Only files you tick and confirm are touched."""
import hashlib, http.server, sys, re, struct, zipfile, json, os, plistlib, secrets, shutil, subprocess, threading, time, webbrowser
from concurrent.futures import ThreadPoolExecutor

HOME = os.path.expanduser("~")
TOKEN = secrets.token_urlsafe(16)
STORE = {}  # id -> {"paths": [...], "mode": "delete"|"trash"}  (only these can be cleaned)

# (category, folder, one item per child?)
JUNK = [
    ("App caches", "~/Library/Caches", True),
    ("Logs", "~/Library/Logs", True),
    ("Developer files", "~/Library/Developer/Xcode/DerivedData", True),
    ("Developer files", "~/Library/Developer/CoreSimulator/Caches", False),
    ("Developer files", "~/.npm/_cacache", False),
    ("Trash", "~/.Trash", True),
]
LIB = ["Application Support", "Caches", "Preferences", "Containers", "Logs",
       "Saved Application State", "HTTPStorages", "WebKit", "Group Containers"]


def du(p):
    try:
        return int(subprocess.run(["du", "-sk", p], capture_output=True, text=True, timeout=180).stdout.split()[0]) * 1024
    except Exception:
        return 0


def sizes(paths):
    with ThreadPoolExecutor(8) as ex:
        return list(ex.map(du, paths))


def make(name, paths, size, cat, mode):
    i = secrets.token_hex(4)
    STORE[i] = {"paths": paths, "mode": mode}
    return {"id": i, "name": name, "sub": paths[0], "size": size, "cat": cat, "mode": mode, "n": len(paths)}


def safe(p):
    rp = os.path.join(os.path.realpath(os.path.dirname(p)), os.path.basename(p))
    for root in (HOME, "/Applications"):
        if rp.startswith(root + os.sep):
            return
    raise ValueError("path not allowed")


def in_home(p):
    rp = os.path.realpath(p)
    return rp == HOME or rp.startswith(HOME + os.sep) or rp.startswith("/Applications")


def trash(p):
    dest = os.path.join(HOME, ".Trash", os.path.basename(p))
    if os.path.exists(dest):
        dest += time.strftime(" %H.%M.%S")
    shutil.move(p, dest)


# ---------- modules ----------
def disk(_):
    u = shutil.disk_usage("/")
    return {"total": u.total, "free": u.free, "used": u.total - u.free}


def junk(_):
    STORE.clear()
    out = []
    for cat, d, kids in JUNK:
        d = os.path.expanduser(d)
        try:
            if not os.path.isdir(d):
                continue
            ps = [os.path.join(d, n) for n in os.listdir(d) if n != ".DS_Store"] if kids else [d]
        except PermissionError:
            continue
        for p, s in zip(ps, sizes(ps)):
            if s >= 1_000_000:
                out.append(make(os.path.basename(p), [p], s, cat, "delete"))
    return {"items": sorted(out, key=lambda x: -x["size"])}


def large(_):
    STORE.clear()
    found = []
    skip = {"Library", "node_modules", "Pictures"}
    for root, dirs, files in os.walk(HOME):
        dirs[:] = [d for d in dirs if not d.startswith(".") and d not in skip
                   and not d.endswith((".app", ".photoslibrary", ".imovielibrary"))]
        for f in files:
            p = os.path.join(root, f)
            try:
                st = os.lstat(p)
                if st.st_size >= 100_000_000 and os.path.isfile(p) and not os.path.islink(p):
                    found.append((st.st_size, st.st_mtime, p))
            except OSError:
                pass
    found.sort(reverse=True)
    out = []
    for s, m, p in found[:50]:
        cat = "Not opened for over a year" if time.time() - m > 365 * 86400 else "Large files (100 MB+)"
        out.append(make(os.path.basename(p), [p], s, cat, "trash"))
    return {"items": out}


def apps(_):
    STORE.clear()
    libs = {}
    for sub in LIB:
        try:
            libs[sub] = os.listdir(os.path.join(HOME, "Library", sub))
        except OSError:
            libs[sub] = []
    found = []
    for base in ("/Applications", os.path.join(HOME, "Applications")):
        try:
            names = sorted(os.listdir(base))
        except OSError:
            continue
        for n in names:
            if not n.endswith(".app"):
                continue
            p = os.path.join(base, n)
            try:
                with open(os.path.join(p, "Contents", "Info.plist"), "rb") as f:
                    bid = plistlib.load(f).get("CFBundleIdentifier", "")
            except Exception:
                bid = ""
            if bid.startswith("com.apple."):
                continue
            stem = n[:-4]
            left = [os.path.join(HOME, "Library", sub, e) for sub, es in libs.items() for e in es
                    if (bid and e.startswith(bid)) or e == stem]
            found.append((n, [p] + left))
    allp = [x for _, ps in found for x in ps]
    sz = dict(zip(allp, sizes(allp)))
    out = [make(n[:-4], ps, sum(sz[x] for x in ps), "Apps and their leftovers", "trash") for n, ps in found]
    return {"items": sorted(out, key=lambda x: -x["size"])}


def lens(b):
    path = b.get("path") or HOME
    if not in_home(path):
        raise ValueError("outside your home folder")
    try:
        ps = [os.path.join(path, n) for n in os.listdir(path) if n != ".DS_Store"]
    except PermissionError:
        raise ValueError("macOS blocked access. Give Terminal 'Full Disk Access' in System Settings.")
    sz = sizes(ps)
    items = [{"name": os.path.basename(p), "path": p, "size": s, "dir": os.path.isdir(p) and not os.path.islink(p)}
             for p, s in zip(ps, sz)]
    return {"path": path, "home": HOME, "items": sorted(items, key=lambda x: -x["size"])[:40]}


BAD = ("mackeeper", "genieo", "installcore", "spigot", "vsearch", "conduit", "operatormac", "shlayer",
       "bundlore", "pirrit", "adload", "silversparrow", "macsearch", "crossrider", "searchbaron",
       "advancedmaccleaner", "macautofixer", "mymacupdater", "zeobit")
TMP = ("/tmp/", "/private/tmp/", "/var/tmp/", "/private/var/tmp/")


def bad_sig(p):
    try:
        return subprocess.run(["codesign", "--verify", "--deep", "--strict", p], capture_output=True, timeout=90).returncode != 0
    except Exception:
        return False


def malware(_):
    STORE.clear()
    out = []
    for d in (HOME + "/Library/LaunchAgents", "/Library/LaunchAgents", "/Library/LaunchDaemons"):
        try:
            names = sorted(os.listdir(d))
        except OSError:
            continue
        for n in names:
            if not n.endswith(".plist") or n.startswith("com.apple."):
                continue
            p = os.path.join(d, n)
            try:
                with open(p, "rb") as f:
                    pl = plistlib.load(f)
            except Exception:
                pl = {}
            prog = str(pl.get("Program") or (pl.get("ProgramArguments") or [""])[0])
            why = []
            if any(x in (n + prog).lower() for x in BAD):
                why.append("matches a known adware or malware name")
            if prog.startswith(TMP):
                why.append("starts from a temporary folder")
            if "/." in prog:
                why.append("runs a hidden file")
            if prog and not os.path.exists(prog):
                why.append("its program is missing")
            if why:
                mine = p.startswith(HOME + os.sep)
                out.append(make(n + ": " + ", ".join(why), [p], 0,
                                "Startup items to review" + ("" if mine else " (system folder, remove by hand)"),
                                "trash" if mine else "view"))
    found = [os.path.join(b, n) for b in ("/Applications", HOME + "/Applications") if os.path.isdir(b)
             for n in sorted(os.listdir(b)) if n.endswith(".app")]
    with ThreadPoolExecutor(6) as ex:
        flags = list(ex.map(bad_sig, found))
    flagged = [p for p, x in zip(found, flags) if x]
    for p, s in zip(flagged, sizes(flagged)):
        out.append(make(os.path.basename(p)[:-4], [p], s, "Apps with a broken or missing signature", "trash"))
    note = ("Found %d item(s) to review. A flag is not proof of a virus, so check each name first." % len(out)
            if out else "No known problems found.") + " This is a basic check, not a full antivirus."
    return {"items": out, "note": note}


def cloud(_):
    STORE.clear()
    out = []
    ic = os.path.join(HOME, "Library", "Mobile Documents", "com~apple~CloudDocs")
    found = []
    for root, dirs, files in os.walk(ic):
        for f in files:
            if f.startswith("."):
                continue
            p = os.path.join(root, f)
            try:
                st = os.lstat(p)
                if st.st_size >= 20_000_000:
                    found.append((st.st_size, p))
            except OSError:
                pass
    for s, p in sorted(found, reverse=True)[:50]:
        out.append(make(os.path.basename(p), [p], s, "iCloud Drive: remove the copy on this Mac (it stays in iCloud)", "evict"))
    others = [HOME + "/Dropbox", HOME + "/Google Drive", HOME + "/OneDrive"]
    cs = os.path.join(HOME, "Library", "CloudStorage")
    if os.path.isdir(cs):
        others += [os.path.join(cs, n) for n in os.listdir(cs)]
    others = [d for d in others if os.path.isdir(d)]
    for d, s in zip(others, sizes(others)):
        out.append(make(os.path.basename(d), [d], s, "Other cloud folders on this Mac (open in Finder to free space)", "view"))
    return {"items": out, "note": "This shows only what is stored on this Mac. Your online storage is not visible without signing in to each service."}


def digest(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


def dups(_):
    STORE.clear()
    by = {}
    for sub in ("Documents", "Downloads", "Desktop", "Pictures", "Movies", "Music"):
        for root, dirs, files in os.walk(os.path.join(HOME, sub)):
            dirs[:] = [d for d in dirs if not d.startswith(".") and not d.endswith((".photoslibrary", ".app", ".imovielibrary"))]
            for f in files:
                p = os.path.join(root, f)
                try:
                    st = os.lstat(p)
                    if not f.startswith(".") and st.st_size >= 1_000_000 and os.path.isfile(p) and not os.path.islink(p):
                        by.setdefault(st.st_size, []).append((st.st_mtime, p))
                except OSError:
                    pass
    groups = []
    for size, lst in by.items():
        if len(lst) < 2:
            continue
        h = {}
        for m, p in lst:
            try:
                h.setdefault(digest(p), []).append((m, p))
            except OSError:
                pass
        groups += [(size, sorted(g)) for g in h.values() if len(g) > 1]
    groups.sort(key=lambda x: -x[0] * (len(x[1]) - 1))
    out = []
    for size, g in groups[:40]:
        cat = "Keeping the oldest copy: ~/" + os.path.relpath(g[0][1], HOME)
        out += [make(os.path.basename(p), [p], size, cat, "trash") for m, p in g[1:]]
    return {"items": out}


def reveal(b):
    if in_home(b["path"]) or b["path"].startswith("/Library/Launch"):
        subprocess.run(["open", "-R", b["path"]])
    return {}


def clean(b):
    freed, errs, n = 0, [], 0
    for i in b["ids"]:
        it = STORE.get(i)
        if not it:
            continue
        for p in it["paths"]:
            try:
                safe(p)
                s = du(p)
                if it["mode"] == "view":
                    continue
                if it["mode"] == "delete":
                    shutil.rmtree(p) if os.path.isdir(p) and not os.path.islink(p) else os.remove(p)
                elif it["mode"] == "evict":
                    subprocess.run(["brctl", "evict", p], check=True)
                elif it["mode"] == "xattr":
                    subprocess.run(["xattr", "-d", ORIGIN, p], capture_output=True)
                elif it["mode"] == "strip":
                    clean_file(p)
                else:
                    trash(p)
                freed += s
                n += 1
            except Exception as e:
                errs.append(os.path.basename(p) + ": " + str(e))
    return {"freed": freed, "errors": errs, "count": n}


def installed_ids():
    ids = set()
    for b in ("/Applications", "/Applications/Utilities", "/System/Applications", HOME + "/Applications"):
        try:
            names = os.listdir(b)
        except OSError:
            continue
        for n in names:
            if n.endswith(".app"):
                try:
                    with open(os.path.join(b, n, "Contents", "Info.plist"), "rb") as fh:
                        ids.add(str(plistlib.load(fh).get("CFBundleIdentifier", "")).lower())
                except Exception:
                    pass
    ids.discard("")
    return ids


def registry(_):
    """macOS has no registry. Its settings live in preference files, so we look for the Mac version of 'registry junk'."""
    STORE.clear()
    out = []
    ids = installed_ids()
    vendors = {".".join(i.split(".")[:2]) for i in ids}

    def known(n):
        n = n.lower()
        return (n.startswith(("com.apple.", "group.com.apple.")) or ".".join(n.split(".")[:2]) in vendors
                or any(n == i or n.startswith(i + ".") or i.startswith(n + ".") for i in ids))

    lib = os.path.join(HOME, "Library")
    spots = (("Preferences", ".plist", "Leftover settings of removed apps"),
             ("Saved Application State", ".savedState", "Leftover window memory of removed apps"),
             ("Containers", "", "Leftover app containers of removed apps"),
             ("HTTPStorages", "", "Leftover web storage of removed apps"),
             ("WebKit", "", "Leftover web data of removed apps"))
    for sub, ext, cat in spots:
        d = os.path.join(lib, sub)
        try:
            names = sorted(os.listdir(d))
        except OSError:
            continue
        for n in names:
            bid = n[:-len(ext)] if ext and n.endswith(ext) else n
            p = os.path.join(d, n)
            if sub == "Preferences" and n.endswith(".plist") and not n.startswith("com.apple."):
                try:
                    with open(p, "rb") as fh:
                        plistlib.load(fh)
                except Exception:
                    out.append(make(n, [p], 0, "Damaged settings files", "trash"))
                    continue
            if bid.count(".") >= 2 and bid[0].isalpha() and not known(bid):
                out.append(make(n, [p], 0, cat, "trash"))
    for it, sz in zip(out, sizes([x["sub"] for x in out])):
        it["size"] = sz
    return {"items": out, "note": "macOS has no Windows-style registry. This checks the Mac version: settings files of apps you removed, and damaged settings files. Unsure items stay in the Trash so you can restore them."}


def tiff_info(t):
    try:
        bo = ">" if t[:2] == b"MM" else "<"
        off = struct.unpack(bo + "I", t[4:8])[0]
        cnt = struct.unpack(bo + "H", t[off:off + 2])[0]
        gps, ori = False, 1
        for k in range(cnt):
            e = t[off + 2 + 12 * k: off + 14 + 12 * k]
            tag = struct.unpack(bo + "H", e[:2])[0]
            if tag == 0x8825:
                gps = True
            elif tag == 0x0112:
                ori = struct.unpack(bo + "H", e[8:10])[0]
        return gps, ori
    except Exception:
        return None


def jpeg_segments(b):
    i = 2
    while i + 4 <= len(b) and b[i] == 0xFF and b[i + 1] not in (0xDA, 0xD9):
        L = struct.unpack(">H", b[i + 2:i + 4])[0]
        yield b[i + 1], i, i + 2 + L
        i += 2 + L


def jpeg_exif(b):
    if b[:2] != b"\xff\xd8":
        return None
    for m, a, z in jpeg_segments(b):
        if m == 0xE1 and b[a + 4:a + 10] == b"Exif\0\0":
            return tiff_info(b[a + 10:z])
    return None


def strip_jpeg(p):
    b = open(p, "rb").read()
    if b[:2] != b"\xff\xd8":
        raise ValueError("not a JPEG")
    out, ori, end = [], 1, 2
    for m, a, z in jpeg_segments(b):
        seg = b[a + 4:z]
        isexif = m == 0xE1 and seg[:6] == b"Exif\0\0"
        if isexif:
            ori = (tiff_info(seg[6:]) or (0, 1))[1]
        if not (isexif or (m == 0xE1 and seg[:4] == b"http") or m == 0xED):
            out.append(b[a:z])
        end = z
    if ori != 1:  # keep only the rotation so the photo still shows the right way up
        ex = (b"Exif\0\0MM\0*\0\0\0\x08\0\x01\x01\x12\0\x03\0\0\0\x01" + struct.pack(">HH", ori, 0) + b"\0\0\0\0")
        out.insert(1 if out and out[0][1:2] == b"\xe0" else 0, b"\xff\xe1" + struct.pack(">H", len(ex) + 2) + ex)
    return b"\xff\xd8" + b"".join(out) + b[end:]


def strip_office(p, tmp):
    with zipfile.ZipFile(p) as zi, zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zo:
        for info in zi.infolist():
            d = zi.read(info)
            if info.filename in ("docProps/core.xml", "docProps/app.xml"):
                d = re.sub(r"(<(?:dc:creator|cp:lastModifiedBy|Company|Manager)>)[^<]*", r"\1", d.decode("utf8", "ignore")).encode()
            zo.writestr(info, d)


def clean_file(p):
    tmp = p + ".clean.tmp"
    try:
        if p.lower().endswith((".jpg", ".jpeg")):
            with open(tmp, "wb") as fh:
                fh.write(strip_jpeg(p))
        else:
            strip_office(p, tmp)
        shutil.copystat(p, tmp)
        trash(p)  # the original goes to the Trash, so you can always get it back
        os.rename(tmp, p)
    finally:
        if os.path.exists(tmp):
            os.remove(tmp)


ORIGIN = "com.apple.metadata:kMDItemWhereFroms"


def has_origin(p):
    try:
        return ORIGIN in subprocess.run(["xattr", p], capture_output=True, text=True, timeout=10).stdout
    except Exception:
        return False


def meta(_):
    STORE.clear()
    out, jpg, off, allf = [], [], [], []
    for d in ("Pictures", "Desktop", "Downloads", "Documents"):
        for root, ds, files in os.walk(os.path.join(HOME, d)):
            ds[:] = [x for x in ds if not x.startswith(".") and not x.endswith((".photoslibrary", ".app"))]
            for n in files:
                if n.startswith("."):
                    continue
                p, l = os.path.join(root, n), n.lower()
                allf.append(p)
                if l.endswith((".jpg", ".jpeg")):
                    jpg.append(p)
                elif l.endswith((".docx", ".xlsx", ".pptx")) and not n.startswith("~$"):
                    off.append(p)
    other = 0
    for p in jpg[:3000]:
        try:
            with open(p, "rb") as fh:
                info = jpeg_exif(fh.read(70000))
            if info and (info[0] or other < 100):
                other += 0 if info[0] else 1
                out.append(make(p and os.path.basename(p) + (" (has GPS location)" if info[0] else " (has camera details)"),
                                [p], os.path.getsize(p), "Photos with GPS location" if info[0] else "Photos with camera details", "strip"))
        except Exception:
            pass
    for p in off[:2000]:
        try:
            with zipfile.ZipFile(p) as z:
                m = re.search(r"<(?:dc:creator|cp:lastModifiedBy)>([^<]+)<", z.read("docProps/core.xml").decode("utf8", "ignore"))
            if m:
                out.append(make(os.path.basename(p) + " (author: " + m.group(1)[:40] + ")", [p], os.path.getsize(p), "Documents with author names", "strip"))
        except Exception:
            pass
    with ThreadPoolExecutor(8) as ex:
        flags = list(ex.map(has_origin, allf[:1500]))
    hit = [p for p, x in zip(allf, flags) if x]
    if hit:
        out.append(make("Download history on %d files" % len(hit), hit, 0, "Download history (the web page each file came from)", "xattr"))
    out.sort(key=lambda x: x["cat"])
    return {"items": out, "note": "Edited photos and documents keep a copy of the original in the Trash. Photos keep their rotation. PDF files are not covered yet."}


SEEN = [0.0]


def ping(_):
    SEEN[0] = time.time()
    return {}


def quit_app(_):
    threading.Timer(0.5, lambda: os._exit(0)).start()
    return {}


def watchdog():
    start = time.time()
    while True:
        time.sleep(5)
        last = SEEN[0]
        if (last and time.time() - last > 180) or (not last and time.time() - start > 180):
            os._exit(0)


ROUTES = {"/api/disk": disk, "/api/junk": junk, "/api/large": large, "/api/apps": apps,
          "/api/lens": lens, "/api/reveal": reveal, "/api/clean": clean,
          "/api/malware": malware, "/api/cloud": cloud, "/api/dups": dups, "/api/registry": registry, "/api/meta": meta, "/api/ping": ping, "/api/quit": quit_app}


class H(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def reply(self, code, body, ct="application/json"):
        b = body.encode()
        self.send_response(code)
        self.send_header("Content-Type", ct)
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def host_ok(self):
        return self.headers.get("Host", "").split(":")[0] in ("127.0.0.1", "localhost")

    def do_GET(self):
        if self.path == "/" and self.host_ok():
            self.reply(200, PAGE.replace("__TOKEN__", TOKEN), "text/html; charset=utf-8")
        else:
            self.reply(404, "{}")

    def do_POST(self):
        if not self.host_ok() or self.headers.get("X-Token") != TOKEN or self.path not in ROUTES:
            return self.reply(403, "{}")
        n = int(self.headers.get("Content-Length", 0))
        try:
            out = ROUTES[self.path](json.loads(self.rfile.read(n) or b"{}"))
        except Exception as e:
            out = {"error": str(e)}
        self.reply(200, json.dumps(out))


PAGE = r"""<!doctype html><html lang="en"><head><meta charset="utf-8"><title>FreeMacCleaner</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
:root{--fog:#E9EFF2;--ink:#12212B;--teal:#0F7B83;--coral:#E5533D;--mute:#5E7380;--line:#D5DEE3}
*{box-sizing:border-box}body{margin:0;display:flex;min-height:100vh;background:var(--fog);color:var(--ink);font:15px/1.5 -apple-system,"SF Pro Text",system-ui,sans-serif}
aside{width:250px;background:var(--ink);color:#DCE6EB;padding:28px 18px;display:flex;flex-direction:column;gap:6px;position:sticky;top:0;height:100vh}
aside h1{font-size:18px;margin:0 0 18px 10px;color:#fff;letter-spacing:.2px}
nav button{display:block;width:100%;text-align:left;border:0;background:none;color:inherit;font:inherit;padding:10px 12px;border-radius:10px;cursor:pointer}
nav button:hover{background:#1D3342}nav button.on{background:var(--teal);color:#fff}
nav button:focus-visible,.btn:focus-visible{outline:2px solid #fff;outline-offset:2px}
.ring{margin-top:auto;text-align:center}.ring svg{width:150px;height:150px}.ring b{display:block;font-size:20px;color:#fff}.ring span{font-size:13px;color:#9FB3BF}
main{flex:1;padding:36px 44px 110px;max-width:900px}
h2{font-size:28px;margin:0 0 4px}.lead{color:var(--mute);margin:0 0 24px;max-width:60ch}
h3{font-size:15px;margin:26px 0 8px;color:var(--mute);font-weight:600}
.row{display:flex;align-items:center;gap:14px;background:#fff;border:1px solid var(--line);border-radius:12px;padding:11px 14px;margin-bottom:8px}
.row input{width:18px;height:18px;accent-color:var(--teal)}.row .t{flex:1;min-width:0}.row .t div{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.row small{color:var(--mute)}.sz{font-weight:600;white-space:nowrap}
.bar{height:6px;border-radius:3px;background:var(--teal);margin-top:6px}
.lensrow{cursor:default}.lensrow.dir{cursor:pointer}.lensrow.dir:hover{border-color:var(--teal)}
.btn{border:0;background:var(--teal);color:#fff;font:inherit;font-weight:600;padding:10px 20px;border-radius:10px;cursor:pointer}
.btn.ghost{background:#fff;color:var(--ink);border:1px solid var(--line)}.btn:disabled{opacity:.4;cursor:default}
.dock{position:fixed;left:250px;right:0;bottom:0;background:#fff;border-top:1px solid var(--line);padding:14px 44px;display:flex;align-items:center;gap:16px}
.dock .sp{flex:1}.dock .btn{background:var(--coral)}
.msg{background:#fff;border-left:4px solid var(--teal);padding:12px 16px;border-radius:8px;margin-bottom:16px}.msg.err{border-color:var(--coral)}
.spin{color:var(--mute);padding:40px 0}
@media(max-width:760px){body{display:block}aside{width:auto;height:auto;position:static}.ring{display:none}main{padding:24px 18px 110px}.dock{left:0;padding:12px 18px}}
.dock[hidden]{display:none}aside{overflow-y:auto}.ring svg{width:120px;height:120px}
.scan{display:flex;flex-direction:column;align-items:center;padding:50px 0;color:var(--mute)}
.radar{position:relative;width:120px;height:120px;margin-bottom:18px}
.radar i{position:absolute;inset:0;border:2px solid var(--teal);border-radius:50%;opacity:0}
.radar:after{content:"";position:absolute;left:50%;top:50%;width:14px;height:14px;margin:-7px;border-radius:50%;background:var(--teal)}
@media(prefers-reduced-motion:no-preference){
.ring circle.v{transition:stroke-dashoffset 1.6s cubic-bezier(.2,.8,.2,1)}
.ring svg{animation:glow 3.5s ease-in-out infinite}@keyframes glow{50%{filter:drop-shadow(0 0 8px #3FC1C9aa)}}
nav button{transition:background .2s,transform .2s}nav button:hover{transform:translateX(4px)}
.btn{transition:transform .15s,opacity .2s,box-shadow .2s}.btn:hover:not(:disabled){transform:translateY(-1px);box-shadow:0 4px 12px #0f7b8340}.btn:active:not(:disabled){transform:scale(.96)}
h2,.lead{animation:rise .5s cubic-bezier(.2,.8,.2,1) both}.lead{animation-delay:.08s}
.row{animation:rise .45s cubic-bezier(.2,.8,.2,1) both;animation-delay:calc(var(--i,0)*35ms);transition:border-color .2s,box-shadow .2s,transform .2s}
.row:hover{box-shadow:0 4px 14px #12212b14;transform:translateY(-1px)}
@keyframes rise{from{opacity:0;transform:translateY(14px)}}
.bar{animation:grow .9s cubic-bezier(.2,.8,.2,1) both;transform-origin:left}@keyframes grow{from{transform:scaleX(0)}}
.msg{animation:pop .45s cubic-bezier(.3,1.4,.5,1) both}@keyframes pop{from{opacity:0;transform:scale(.94)}}
.dock{animation:up .45s cubic-bezier(.2,.8,.2,1) both}@keyframes up{from{transform:translateY(100%)}}
.radar i{animation:ping 2.4s ease-out infinite}.radar i:nth-child(2){animation-delay:.8s}.radar i:nth-child(3){animation-delay:1.6s}
@keyframes ping{from{opacity:.8;transform:scale(.1)}to{opacity:0;transform:scale(1)}}
.radar:after{animation:beat 1.2s ease-in-out infinite alternate}@keyframes beat{to{transform:scale(1.5)}}
.scan p{animation:fade 1.4s ease-in-out infinite alternate}@keyframes fade{from{opacity:.35}}
nav button{animation:slidein .5s cubic-bezier(.2,.8,.2,1) backwards;animation-delay:calc(var(--n,0)*55ms)}@keyframes slidein{from{opacity:0;transform:translateX(-20px)}}
.row.gone{animation:gone .55s ease forwards;overflow:hidden}@keyframes gone{35%{background:#d9f2f0;transform:scale(1.015)}to{opacity:0;transform:translateX(50px) scale(.96)}}
.dock .btn.busy{background:linear-gradient(90deg,#E5533D,#f3a08f,#E5533D);background-size:200% 100%;animation:shine 1s linear infinite}@keyframes shine{to{background-position:-200% 0}}
}
</style></head><body>
<aside><h1>FreeMacCleaner</h1>
<nav id="nav"></nav>
<div class="ring"><svg viewBox="0 0 120 120"><circle cx="60" cy="60" r="50" fill="none" stroke="#1D3342" stroke-width="10"/>
<circle class="v" id="arc" cx="60" cy="60" r="50" fill="none" stroke="#3FC1C9" stroke-width="10" stroke-linecap="round" stroke-dasharray="314" stroke-dashoffset="314" transform="rotate(-90 60 60)"/></svg>
<b id="free">-</b><span id="used"></span></div><button class="btn ghost" id="quit" style="margin-top:14px">Quit FreeMacCleaner</button></aside>
<main id="main"></main><div class="dock" id="dock" hidden></div>
<script>
const T="__TOKEN__",$=s=>document.querySelector(s);
const fmt=b=>b>=1e9?(b/1e9).toFixed(1)+" GB":b>=1e6?Math.round(b/1e6)+" MB":Math.round(b/1e3)+" KB";
const esc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
async function api(u,b){const r=await fetch(u,{method:"POST",headers:{"X-Token":T,"Content-Type":"application/json"},body:JSON.stringify(b||{})});return r.json()}
const V={
 junk:{n:"Smart Cleanup",h:"Remove junk safely",d:"Finds app caches, old logs, developer leftovers and Trash. Apps rebuild caches by themselves. These items are deleted for good, so review the list first.",all:1,wait:"Scanning junk files..."},
 large:{n:"Large & Old Files",h:"Find files that take the most room",d:"Files over 100 MB in your home folder. Nothing is ticked for you. Ticked files go to the Trash, so you can still get them back.",wait:"Looking for big files. This can take a minute..."},
 apps:{n:"App Uninstaller",h:"Remove apps with their leftovers",d:"Apps and the hidden files they leave in your Library. Ticked apps go to the Trash.",wait:"Reading your apps..."},
 dups:{n:"Duplicate Finder",h:"Find files that exist twice",d:"Looks for identical files (1 MB+) in Documents, Downloads, Desktop, Pictures, Movies and Music. The oldest copy is kept. The extra copies are ticked and go to the Trash.",all:1,wait:"Comparing files. This can take a few minutes..."},
 malware:{n:"Malware Check",h:"Check for suspicious items",d:"Looks at startup items and app signatures for signs of adware or tampering. Ticked items go to the Trash.",wait:"Checking startup items and apps..."},
 cloud:{n:"Cloud Cleanup",h:"Free space used by cloud files",d:"Finds big iCloud Drive files stored on this Mac. Removing the Mac copy keeps the file in iCloud. You can download it again any time.",wait:"Looking at your cloud folders..."},
 registry:{n:"Registry Cleaner",h:"Clean leftover settings",d:"Windows has a registry. Macs keep settings in preference files instead. This finds files left by apps you removed, and damaged files. Ticked items go to the Trash.",wait:"Reading settings files..."},
 meta:{n:"Metadata Cleaner",h:"Remove hidden personal details",d:"Photos can hide your GPS location. Office files can hide author names. Downloads remember the web page they came from. Review the list, then clean.",all:1,wait:"Looking inside your files..."},
 lens:{n:"Space Lens",h:"See what fills your drive",d:"Click a folder to look inside. This view only shows sizes. It never deletes anything."}};
let view="junk",items=[],sel=new Set();
$("#nav").innerHTML=Object.keys(V).map((k,n)=>`<button data-k="${k}" style="--n:${n}">${V[k].n}</button>`).join("");
$("#nav").onclick=e=>{const k=e.target.dataset.k;if(k)load(k)};
function count(el,to){if(matchMedia("(prefers-reduced-motion:reduce)").matches)return;const t0=performance.now();(function f(t){const p=Math.min(1,(t-t0)/900);el.textContent=fmt(to*(1-Math.pow(1-p,3)));if(p<1)requestAnimationFrame(f)})(t0)}
async function disk(){const d=await api("/api/disk");$("#free").textContent=fmt(d.free)+" free";$("#used").textContent=fmt(d.used)+" of "+fmt(d.total)+" used";$("#arc").style.strokeDashoffset=314*(1-d.used/d.total)}
async function load(k,note){view=k;sel=new Set();document.querySelectorAll("nav button").forEach(b=>b.classList.toggle("on",b.dataset.k==k));
 $("#dock").hidden=true;const v=V[k];$("#main").innerHTML=`<h2>${v.h}</h2><p class="lead">${v.d}</p>${note||""}<div class="scan"><div class="radar"><i></i><i></i><i></i></div><p>${v.wait||"Loading..."}</p></div>`;
 if(k=="lens")return lens();
 const r=await api("/api/"+k);if(r.error)return $("#main").insertAdjacentHTML("beforeend",`<div class="msg err">${esc(r.error)}</div>`);
 items=r.items;if(v.all)items.forEach(i=>i.mode!="view"&&sel.add(i.id));list((note||"")+(r.note?`<div class="msg">${esc(r.note)}</div>`:""))}
function list(note){const v=V[view];let h=`<h2>${v.h}</h2><p class="lead">${v.d}</p>${note||""}`;
 if(!items.length)h+=`<div class="msg">Nothing to clean here. Your Mac looks tidy.</div>`;
 const g={};items.forEach(i=>(g[i.cat]=g[i.cat]||[]).push(i));
 for(const c in g)h+=`<h3>${esc(c)} (${fmt(g[c].reduce((a,i)=>a+i.size,0))})</h3>`+g[c].map((i,k)=>`<label class="row" style="--i:${Math.min(k,15)}">${i.mode=="view"?`<button class="btn ghost" data-rv="${esc(i.sub)}">Show</button>`:`<input type="checkbox" data-id="${i.id}" ${sel.has(i.id)?"checked":""}>`}
 <div class="t"><div>${esc(i.name)}${i.n>1?` <small>+ ${i.n-1} more</small>`:""}</div><small>${esc(i.sub)}</small></div><span class="sz">${fmt(i.size)}</span></label>`).join("");
 $("#main").innerHTML=h;$("#main").onclick=e=>{const p=e.target.dataset.rv;if(p){e.preventDefault();api("/api/reveal",{path:p})}};$("#main").onchange=e=>{const id=e.target.dataset.id;if(!id)return;e.target.checked?sel.add(id):sel.delete(id);dock()};dock()}
function dock(){const d=$("#dock"),pk=items.filter(i=>i.mode!="view");d.hidden=!pk.length;const tot=items.filter(i=>sel.has(i.id)).reduce((a,i)=>a+i.size,0);
 d.innerHTML=`<span><b>${sel.size}</b> selected, ${fmt(tot)}</span><span class="sp"></span><button class="btn ghost" id="all">${sel.size==pk.length?"Untick all":"Tick all"}</button><button class="btn" id="go" ${sel.size?"":"disabled"}>${{junk:"Delete selected",cloud:"Remove from this Mac",meta:"Clean metadata"}[view]||"Move to Trash"}</button>`;
 $("#all").onclick=()=>{sel.size==pk.length?sel.clear():pk.forEach(i=>sel.add(i.id));list()};
 $("#go").onclick=async()=>{const how={junk:"permanently deleted",cloud:"removed from this Mac (they stay online)",meta:"cleaned. Edited photos and documents keep a copy in the Trash"}[view]||"moved to the Trash";if(!confirm(`${sel.size} item(s) will be ${how}. Continue?`))return;
  $("#go").disabled=true;$("#go").classList.add("busy");$("#go").textContent="Cleaning...";document.querySelectorAll("input[data-id]:checked").forEach(c=>c.closest(".row").classList.add("gone"));const[r]=await Promise.all([api("/api/clean",{ids:[...sel]}),new Promise(z=>setTimeout(z,600))]);await disk();
  const e=r.errors&&r.errors.length?`<div class="msg err">${r.errors.length} item(s) failed. macOS may need Full Disk Access for Terminal.<br><small>${esc(r.errors.slice(0,3).join(" | "))}</small></div>`:"";
  const done=view=="meta"?`<div class="msg">Done. <b>${r.count}</b> file(s) cleaned.</div>`:`<div class="msg">Done. <b class="cnt" data-v="${r.freed}">${fmt(r.freed)}</b> cleaned.</div>`;await load(view,done+e);document.querySelectorAll(".cnt").forEach(el=>count(el,+el.dataset.v))}}
async function lens(p){const r=await api("/api/lens",{path:p});if(r.error)return $("#main").insertAdjacentHTML("beforeend",`<div class="msg err">${esc(r.error)}</div>`);
 const max=Math.max(1,...r.items.map(i=>i.size));$("#dock").hidden=true;
 $("#main").innerHTML=`<h2>${V.lens.h}</h2><p class="lead">${esc(r.path)}</p>`+(r.path!=r.home?`<p><button class="btn ghost" id="up">Back to parent folder</button></p>`:"")+
 r.items.map((i,k)=>`<div class="row lensrow ${i.dir?"dir":""}" data-k="${k}" style="--i:${Math.min(k,15)}"><div class="t"><div>${i.dir?"Folder: ":""}${esc(i.name)}</div><div class="bar" style="width:${Math.max(2,i.size/max*100)}%"></div></div><span class="sz">${fmt(i.size)}</span><button class="btn ghost" data-r="${k}">Show in Finder</button></div>`).join("");
 if($("#up"))$("#up").onclick=()=>lens(r.path.slice(0,r.path.lastIndexOf("/")));
 $("#main").onclick=e=>{const rv=e.target.dataset.r;if(rv!=null){e.stopPropagation();return api("/api/reveal",{path:r.items[rv].path})}
  const row=e.target.closest(".lensrow.dir");if(row){$("#main").innerHTML+=`<div class="spin">Measuring...</div>`;lens(r.items[row.dataset.k].path)}}}
disk();load("junk");api("/api/ping");setInterval(()=>api("/api/ping"),10000);
$("#quit").onclick=async()=>{await api("/api/quit");document.body.innerHTML=`<p style="padding:40px;font:16px sans-serif">FreeMacCleaner has quit. You can close this tab.</p>`};
</script></body></html>"""


def main():
    srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), H)
    url = "http://127.0.0.1:%d/" % srv.server_address[1]
    print("FreeMacCleaner is running at", url, flush=True)
    if "--native" in sys.argv:
        def orphan():
            while os.getppid() != 1:
                time.sleep(3)
            os._exit(0)
        threading.Thread(target=orphan, daemon=True).start()
    else:
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
        threading.Thread(target=watchdog, daemon=True).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nBye!")


if __name__ == "__main__":
    main()
