FreeMacCleaner - native Mac app (source + build script)

1. Unzip this folder.
2. Open Terminal and type:  cd   (then drag this folder into the Terminal window and press Enter)
3. Run:  ./build.sh      (if it says permission denied, run: chmod +x build.sh   then try again)
4. Drag the new FreeMacCleaner.app into Applications and open it.

Because you build it on your own Mac, macOS does not show the "unidentified developer" warning.
If macOS asks to install Command Line Tools, accept, wait, then run ./build.sh again.
For full scans: System Settings > Privacy & Security > Full Disk Access > add FreeMacCleaner.
