#!/bin/bash
# Builds FreeMacCleaner.app on your own Mac. Needs Apple Command Line Tools (xcode-select --install).
set -e
cd "$(dirname "$0")"
APP="FreeMacCleaner.app"
rm -rf "$APP"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
swiftc -O -o "$APP/Contents/MacOS/FreeMacCleaner" main.swift -framework Cocoa -framework WebKit
cp FreeMacCleaner.py AppIcon.icns "$APP/Contents/Resources/"
cp Info.plist "$APP/Contents/Info.plist"
codesign --force --deep -s - "$APP"
echo ""
echo "Done! Drag FreeMacCleaner.app into your Applications folder."
open .
