import Cocoa
import WebKit

// FreeMacCleaner: native macOS shell. It runs the cleaner engine (Python, local only)
// and shows its screen inside a real Mac window.
final class AppDelegate: NSObject, NSApplicationDelegate, WKUIDelegate {
    var window: NSWindow!
    var web: WKWebView!
    var server: Process?
    var loaded = false

    func applicationDidFinishLaunching(_ note: Notification) {
        buildMenu()
        web = WKWebView(frame: .zero, configuration: WKWebViewConfiguration())
        web.uiDelegate = self
        window = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 1120, height: 760),
                          styleMask: [.titled, .closable, .miniaturizable, .resizable],
                          backing: .buffered, defer: false)
        window.title = "FreeMacCleaner"
        window.contentView = web
        window.minSize = NSSize(width: 820, height: 560)
        window.isReleasedWhenClosed = false
        window.center()
        startServer()
        DispatchQueue.main.asyncAfter(deadline: .now() + 20) { [weak self] in
            if let s = self, !s.loaded { s.fail("The cleaner engine did not start. Make sure Apple Command Line Tools are installed.") }
        }
    }

    func startServer() {
        guard let script = Bundle.main.path(forResource: "FreeMacCleaner", ofType: "py") else {
            fail("The engine file is missing from the app."); return
        }
        let p = Process()
        p.executableURL = URL(fileURLWithPath: "/usr/bin/python3")
        p.arguments = [script, "--native"]
        let pipe = Pipe()
        p.standardOutput = pipe
        p.standardError = FileHandle.nullDevice
        p.terminationHandler = { _ in DispatchQueue.main.async { NSApp.terminate(nil) } }
        pipe.fileHandleForReading.readabilityHandler = { [weak self] h in
            let d = h.availableData
            if d.isEmpty { h.readabilityHandler = nil; return }
            let text = String(decoding: d, as: UTF8.self)
            guard let r = text.range(of: "http://127.0.0.1:[0-9]+/", options: .regularExpression),
                  let url = URL(string: String(text[r])) else { return }
            h.readabilityHandler = nil
            DispatchQueue.main.async {
                self?.loaded = true
                self?.web.load(URLRequest(url: url))
                self?.window.makeKeyAndOrderFront(nil)
                NSApp.activate(ignoringOtherApps: true)
            }
        }
        do { try p.run(); server = p } catch { fail("Could not start Python: \(error.localizedDescription)") }
    }

    func fail(_ message: String) {
        let a = NSAlert()
        a.messageText = "FreeMacCleaner"
        a.informativeText = message
        a.runModal()
        NSApp.terminate(nil)
    }

    // The page uses confirm() before it cleans anything. WKWebView needs us to show that box.
    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
        let a = NSAlert()
        a.messageText = "FreeMacCleaner"
        a.informativeText = message
        a.addButton(withTitle: "Continue")
        a.addButton(withTitle: "Cancel")
        a.beginSheetModal(for: window) { completionHandler($0 == .alertFirstButtonReturn) }
    }

    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
        let a = NSAlert()
        a.messageText = "FreeMacCleaner"
        a.informativeText = message
        a.beginSheetModal(for: window) { _ in completionHandler() }
    }

    func buildMenu() {
        let bar = NSMenu()
        let appItem = NSMenuItem(); bar.addItem(appItem)
        let appMenu = NSMenu()
        appMenu.addItem(withTitle: "Quit FreeMacCleaner", action: #selector(NSApplication.terminate(_:)), keyEquivalent: "q")
        appItem.submenu = appMenu
        let winItem = NSMenuItem(); bar.addItem(winItem)
        let win = NSMenu(title: "Window")
        win.addItem(withTitle: "Minimize", action: #selector(NSWindow.performMiniaturize(_:)), keyEquivalent: "m")
        win.addItem(withTitle: "Close", action: #selector(NSWindow.performClose(_:)), keyEquivalent: "w")
        winItem.submenu = win
        NSApp.mainMenu = bar
        NSApp.windowsMenu = win
    }

    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool { true }
    func applicationWillTerminate(_ note: Notification) { server?.terminate() }
}

let app = NSApplication.shared
let delegate = AppDelegate()
app.delegate = delegate
app.setActivationPolicy(.regular)
app.run()
